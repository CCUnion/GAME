/*
�C���y�{�G�C���}�l�e���ﶵ(�bmain�̭�) -> ���d1 -> ���d2 -> ���d3 -> ���� -> �C����������O����
//gcc -o main.exe main.c initial.c collision.c move.c generate.c game.c -lSDL2 -lSDL2_image -lSDL2_mixer -lSDL2_ttf

*/

#include "basic.h"
#include "initial.h"
#include "collision.h"
#include "move.h"
#include "generate.h"
#include "game.h"
#include "string.h"

//�ŧi�Ҧ�extern���ܼ�
struct character character = {.x = CHARACTER_X, .y = CHARACTER_Y, .offset_x = 0, .offset_y = 0};
int map[MAP_HEIGHT / ITEM_SIZE][MAP_WIDTH / ITEM_SIZE];
struct mapPoint mapPoint = {.x = MAPPOINT_X, .y = MAPPOINT_Y, .offset_x = 0, .offset_y = 0};
struct mouse mouse[TOTAL_MOUSE];
struct hp hp = {.full = TOTAL_HP, .empty = 0, .deadOrNot = false};
int whiteMouse;
int blackMouse;
//wordle
int wordle_row, wordle_column;

//lose�Bwin
bool lose;
bool win;

//**�}�l�������禡**//
// ���s���x�ΩM���A
SDL_Rect startButtonRect = {300, 400, 200, 50};
SDL_Rect exitButtonRect = {300, 500, 200, 50};
bool isMouseOverStartButton = false;
bool isMouseOverExitButton = false;
bool isMouseDown = false;

// ���J�Ϲ������
SDL_Texture* loadTexture(const char* path) {
    SDL_Surface* surface = IMG_Load(path);
    if (!surface) {
        printf("Unable to load image %s! SDL_image Error: %s\n", path, IMG_GetError());
        return NULL;
    }
    SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);
    SDL_FreeSurface(surface);
    return texture;
}

// ø�s��r�����
void renderText(const char* text, int x, int y, SDL_Color color) {
    SDL_Surface* textSurface = TTF_RenderText_Solid(startFont, text, color);
    if (textSurface == NULL) {
        printf("Unable to render text surface! SDL_ttf Error: %s\n", TTF_GetError());
        return;
    }
    SDL_Texture* textTexture = SDL_CreateTextureFromSurface(renderer, textSurface);
    if (textTexture == NULL) {
        printf("Unable to create texture from rendered text! SDL Error: %s\n", SDL_GetError());
        SDL_FreeSurface(textSurface);
        return;
    }

    SDL_Rect renderQuad = { x, y, textSurface->w, textSurface->h };
    SDL_RenderCopy(renderer, textTexture, NULL, &renderQuad);

    SDL_FreeSurface(textSurface);
    SDL_DestroyTexture(textTexture);
}

// ø�s�a�y��ĪG����r
void renderTextWithOutline(const char* text, int x, int y, SDL_Color color, SDL_Color outlineColor, int startFontSize, int outlineWidth) {
    TTF_Font* startFont = TTF_OpenFont("Cubic_11_1.100_R.ttf", startFontSize);
    if (startFont == NULL) {
        printf("Failed to load startFont! TTF_Error: %s\n", TTF_GetError());
        return;
    }
    
    TTF_SetFontOutline(startFont, outlineWidth);
    SDL_Surface* outlineSurface = TTF_RenderText_Solid(startFont, text, outlineColor);
    SDL_Texture* outlineTexture = SDL_CreateTextureFromSurface(renderer, outlineSurface);
    
    TTF_SetFontOutline(startFont, 0);
    SDL_Surface* textSurface = TTF_RenderText_Solid(startFont, text, color);
    SDL_Texture* textTexture = SDL_CreateTextureFromSurface(renderer, textSurface);

    if (outlineTexture && textTexture) {
        SDL_Rect outlineQuad = { x, y, outlineSurface->w, outlineSurface->h };
        SDL_Rect textQuad = { x + outlineWidth, y + outlineWidth, textSurface->w, textSurface->h };
        SDL_RenderCopy(renderer, outlineTexture, NULL, &outlineQuad);
        SDL_RenderCopy(renderer, textTexture, NULL, &textQuad);
    } else {
        printf("Unable to create texture from rendered text! SDL Error: %s\n", SDL_GetError());
    }

    SDL_FreeSurface(outlineSurface);
    SDL_FreeSurface(textSurface);
    SDL_DestroyTexture(outlineTexture);
    SDL_DestroyTexture(textTexture);
    //TTF_CloseFont(startFont);
}

// ø�s����
void drawScene() {
    // �M�ſù�
    SDL_SetRenderDrawColor(renderer, 30, 30, 30, 255); // �`�Ǧ�I��
    //SDL_RenderClear(renderer);

    // ø�s�Фl
        SDL_Rect startPageRect = {.h = SCREEN_HEIGHT, .w = SCREEN_WIDTH, .x = 0, .y = 0};
        SDL_RenderCopy(renderer, startPageTexture, NULL, &startPageRect);

    // ø�s���s
    if (isMouseOverStartButton) {
        SDL_SetRenderDrawColor(renderer, 0, 255, 0, 255); // ��Ⱚ�G
    } else {
        SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255); // �Ŧ�
    }
    SDL_RenderFillRect(renderer, &startButtonRect);

    if (isMouseOverExitButton) {
        SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255); // ���Ⱚ�G
    } else {
        SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255); // �Ŧ�
    }
    SDL_RenderFillRect(renderer, &exitButtonRect);

    // ø�s���D
    SDL_Color textColor = { 255, 255, 255, 255 };
    SDL_Color outlineColor = { 0, 0, 0, 255 }; // �y���C�⬰�¦�
    int startFontSize = 44; // �r��j�p
    int outlineWidth = 2; // �y��e��
    int textX = (SCREEN_WIDTH - (strlen("Mickey Maze in Crazy Cruel University") * startFontSize / 2)) / 2; // �ϼ��D�����~��
    int textY = 50;

    // �T�O���D�j�p�b�ù��d��
    
    TTF_SetFontOutline(startFont, outlineWidth);
    SDL_Surface* textSurface = TTF_RenderText_Solid(startFont, "Mickey Maze in Crazy Cruel University", textColor);
    int textWidth = textSurface->w;
    int textHeight = textSurface->h;
    SDL_FreeSurface(textSurface);

    textX = (SCREEN_WIDTH - textWidth) / 2; // �ϼ��D�����~��

    renderTextWithOutline("Mickey Maze in Crazy Cruel University", 4, textY, textColor, outlineColor, 34, outlineWidth);

    // ø�s���s��r

    renderTextWithOutline("Start Game", 320, 410, textColor, outlineColor, 28, outlineWidth);
    renderTextWithOutline("Exit", 380, 510, textColor, outlineColor, 28, outlineWidth);

    //TTF_CloseFont(startFont); // �ϥΧ����������r��

    // ��s�ù�
    SDL_RenderPresent(renderer);
}

// �B�z�ƹ��ƥ�
void handleMouseEvent(SDL_Event* event, bool *quit) {
    if (event->type == SDL_MOUSEMOTION) {
        int x, y;
        SDL_GetMouseState(&x, &y);
        if (x >= startButtonRect.x && x <= startButtonRect.x + startButtonRect.w &&
            y >= startButtonRect.y && y <= startButtonRect.y + startButtonRect.h) {
            isMouseOverStartButton = true;
        } else {
            isMouseOverStartButton = false;
        }

        if (x >= exitButtonRect.x && x <= exitButtonRect.x + exitButtonRect.w &&
            y >= exitButtonRect.y && y <= exitButtonRect.y + exitButtonRect.h) {
            isMouseOverExitButton = true;
        } else {
            isMouseOverExitButton = false;
        }
    } else if (event->type == SDL_MOUSEBUTTONDOWN) {
        int x, y;
        SDL_GetMouseState(&x, &y);
        if (x >= startButtonRect.x && x <= startButtonRect.x + startButtonRect.w &&
            y >= startButtonRect.y && y <= startButtonRect.y + startButtonRect.h) {
            isMouseDown = true;
        }

        if (x >= exitButtonRect.x && x <= exitButtonRect.x + exitButtonRect.w &&
            y >= exitButtonRect.y && y <= exitButtonRect.y + exitButtonRect.h) {
            isMouseDown = true;
        }
    } else if (event->type == SDL_MOUSEBUTTONUP) {
        if (isMouseDown) {
            int x, y;
            SDL_GetMouseState(&x, &y);
            if (x >= startButtonRect.x && x <= startButtonRect.x + startButtonRect.w &&
                y >= startButtonRect.y && y <= startButtonRect.y + startButtonRect.h) {
                // �b���B�K�[�C���}�l���޿�
                printf("START!\n");
                *quit = true;
            }

            if (x >= exitButtonRect.x && x <= exitButtonRect.x + exitButtonRect.w &&
                y >= exitButtonRect.y && y <= exitButtonRect.y + exitButtonRect.h) {
                // �b���B�K�[�C���h�X���޿�
                printf("EXIT!\n");
                closeSDL();
                exit(0);
            }
        }
        isMouseDown = false;
    }
}
//**�}�l�������禡**//


int main(int argc, char *argv[]){
    
    //��l��:�Ыؿù��Mrenderer
    initBasic();
    //�r��
    initFont();
    //��l��wordle���� **����
    initWordlePicture();
    //��l��start�Ϥ�
    initStartPicture();
    //��l�ƭI�]�Ϥ�
    initBagPicture();
    //��l�Ʃ���Ϥ�
    initluckyDrawPicture();
    //��l�ƶ}�l�������Ϥ�
    initStartPicture();


    //**�}�l�������ﶵ**//
    bool quit = false;
        while (!quit) {
                SDL_Event e;
            while (SDL_PollEvent(&e) != 0) {
                if (e.type == SDL_QUIT) {
                    closeSDL();
                    exit(0);
                    
                }
                handleMouseEvent(&e, &quit);
            }
            drawScene();
        }
    //**�}�l�������ﶵ**//


    //level1~3
    LV level = LEVEL_1;
    bool levelWin = false;
    bool gameQuit = false;
    while(1){
        level1_3(level, &levelWin, &gameQuit);
        if(gameQuit)
            break;
        if(level == LEVEL_1 && levelWin == true){
            level = LEVEL_2;
            levelWin = false;
        }
        else if(level == LEVEL_2 && levelWin == true){
            level = LEVEL_3;
            levelWin = false;
        }
        else if(level == LEVEL_3 && levelWin == true){
            level = LEVEL_END;
        }
        if(level == LEVEL_END){
            end(level);
            break;
        }
    }
    //��ӹC����������O����
    closeSDL();
    exit(0);

}
